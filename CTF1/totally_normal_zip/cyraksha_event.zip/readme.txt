There is nothing hidden in this archive.
Promise.